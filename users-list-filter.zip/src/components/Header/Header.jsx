const Header = () => {
  return (
    <h1 className="text-3xl text-center font-bold mb-12">List of users</h1>
  );
};

export default Header;
